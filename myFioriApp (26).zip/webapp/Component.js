sap.ui.define(["sap/ui/core/UIComponent"],
	function(UIComponent){
			return UIComponent.extend("oft.fiori.nov.Component",{
			metadata:{
				"manifest":"json"
			},
			init:function(){
				//caling the base class constructor to activate the base
				sap.ui.core.UIComponent.prototype.init.apply(this);
				var oRouter = this.getRouter();
				oRouter.initialize();
				
			},
			// createContent:function(){
			// var oAnubhav = new sap.ui.view("idMyXm0",{
			// 	viewName: "oft.fiori.nov.view.App",
			// 	type: sap.ui.core.mvc.ViewType.XML			//"sap.ui.core.mvc.ViewType.XML"
			// });
			
			// var oView1 = new sap.ui.view("idMyXml1",{
			// 	viewName: "oft.fiori.nov.view.View1",
			// 	type: sap.ui.core.mvc.ViewType.XML			//"sap.ui.core.mvc.ViewType.XML"
			// });
			
			// var oView2 = new sap.ui.view("idMyXml2",{
			// 	viewName: "oft.fiori.nov.view.View2",
			// 	type: sap.ui.core.mvc.ViewType.XML			//"sap.ui.core.mvc.ViewType.XML"
			// });
			
			// var oApp = oAnubhav.byId("idApp");				// here we are getting split app object
			// //oApp.addPage(oView1).addPage(oView2);
			// oApp.addMasterPage(oView1).addDetailPage(oView2);
			
			// return oAnubhav;
			// },
			destroy:function(){}
		});	
});
// sap.ui.define(["sap/ui/core/UIComponent"],`
// 	function(UIComponent){
// 		return UIComponent.extend("oft.fiori.nov",{
// 			metadata:{},
// 			init:function(){},
// 			createContent:function(){},
// 			destroy:function(){}
// 		});
// 	});