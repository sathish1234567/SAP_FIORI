sap.ui.define(
	["oft/fiori/nov/controller/BaseController",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator"
	],
	function (Controller, Filter, FilterOperator) {
		"use strict";

		return Controller.extend("oft.fiori.nov.controller.View1", {
			onShowMe: function (oEvnt) {
				//step1- get the object of the Parent for both the view: Parent is container Control
				var oApp = this.getView().getParent();
				//step2: call the method "to()", --> use for navigate to another view  by passing id( i.e view id )
				oApp.to("idMyXml2");
			},

			onUpdate: function (oEvnt) {
				debugger;
				var oListActual = oEvnt.getSource();
				oListActual.setSelectedItem(oListActual.getItems()[0]);
				var oView2 = this.getView().getParent().getParent().getDetailPages()[0];
				oView2.bindElement("/fruits/0");
			},

			onItemPress: function (oEvnt) {
				var oItemPress = oEvnt.getParameter("listItem");
				var addressOfSelectedItem = oItemPress.getBindingContextPath();
				//var oView2 = this.getView().getParent().getPages()[1];
				//oView2.bindElement(addressOfSelectedItem);
				var oView2 = this.getView().getParent().getParent().getDetailPages()[0];
				oView2.bindElement(addressOfSelectedItem);
				this.onShowMe(oEvnt);
			},

			onInit: function (oEvnt) {
				var oList = this.getView().byId("idDynamic");
				oList.bindAggregation("items", {
					path: "/fruits",
					template: new sap.m.ObjectListItem({
						intro: "{type}",
						title: "{name}",
						number: "{price}",
						numberUnit: "{unit}",
						icon: "{image}"
					})

				});

				// this.getView().addEventDelegate({
				// 	// debugger;
				// 	onBeforeFirstShow: function (oEvn) {
				// 		//debugger;
				// 		var oView2 = this.getView().getParent().getParent().getDetailPages()[0];
				// 		oView2.bindElement("/fruits/0");
				// 	}.bind(this)
				// });
				// this.getView().addEventDelegate({
				// 	onAfterRendering: function(){
				// 		debugger;
				// 		//check if nothing is selected
				// 		if(this.getSelectedItem() === null){
				// 			var items = this.getItems();
				// 			// check if there are items
				// 			if(items && items > 0){
				// 				this.setselectedItem(items[0], true);
				// 			}
				// 		}
				// 	}
				// }, oList);
			},
			onSearch: function (oEvnt) {
					var searchStr = oEvnt.getParameter("query");
					var oFilter = new Filter("name", FilterOperator.Contains, searchStr);
					var oFilter1 = new Filter("type", FilterOperator.Contains, searchStr);
					var oMainFilter = new Filter({
						filters: [oFilter, oFilter1],
						and: false
					});
					var aFilter = [oMainFilter];

					// now get the object of the List controller from view1
					var oList = this.getView().byId("idFruits");
					oList.getBinding("items").filter(aFilter);
				}
				/* init()
			// onInit: function(){
				
			// },
		
			
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf jerry.view.anubhav
			 */
				//	onBeforeRendering: function() {
				//
				//	},

			/**
			 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
			 * This hook is the same one that SAPUI5 controls get after being rendered.
			 * @memberOf jerry.view.anubhav
			 */
			//	onAfterRendering: function() {
			//
			//	},

			/**
			 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
			 * @memberOf jerry.view.anubhav
			 */
			//	onExit: function() {
			//
			//	}

		});

	});